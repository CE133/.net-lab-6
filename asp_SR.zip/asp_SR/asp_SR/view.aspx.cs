﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp_SR
{
    public partial class view : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            string una = Session["uname"].ToString();
            uname.Text = una;
            string f = Session["fav"].ToString();
            food.Text = f;
            string g = Session["gender"].ToString();
            gender.Text = g;
        }

        protected void signout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Server.Transfer("reg2.aspx");
        }
    }
}