﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp_SR
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            string una = Session["uname"].ToString();
            uname.Text = una;
        }
        
        protected void submit_Click(object sender, EventArgs e)
        {

            int[] index;
            index = list1.GetSelectedIndices();
            string bhavtu="";
            foreach (int i in index)
            {
                bhavtu = bhavtu + "," + list1.Items[i];
            }
            string g = gender.SelectedItem.Text;
            Session["fav"] = bhavtu;
            Session["gender"] = g;
            Response.Redirect("view.aspx");

        }
    }
}